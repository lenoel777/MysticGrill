package Regis_Login;

import HomePage.Home;
import database.Connect;
import javafx.application.Application;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.layout.HBox;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class Login extends Application {

    private TextField username;
    private PasswordField password;
    private Button loginButton;
    private Hyperlink registerLink;
    private Connect connection;

    public Login() {
		super();
		this.username = username;
		this.password = password;
	}

    public Login(Connect connection) {
        this.connection = connection.getConnection();
    }

    @Override
    public void start(Stage primaryStage) {
        username = new TextField();
        username.setPromptText("Username");

        password = new PasswordField();
        password.setPromptText("Password");

        loginButton = new Button("Login");
        loginButton.setOnAction(e -> loginAction(primaryStage));

        registerLink = new Hyperlink("Don't Have an Account Yet? Register Here");
        registerLink.setOnAction(e -> moveToRegisterPage(primaryStage));

        HBox titleBox = new HBox();
        titleBox.getChildren().add(titleLabel());
        titleBox.setAlignment(Pos.CENTER);

        VBox vbox = new VBox(10);
        vbox.getChildren().addAll(titleBox, createLayout(username, password, loginButton, registerLink));
        vbox.setAlignment(Pos.CENTER);

        Scene loginScene = new Scene(vbox, 300, 200);
        primaryStage.setScene(loginScene);
        primaryStage.setTitle("Login Page");
        primaryStage.show();
    }

    private Label titleLabel() {
        Label title = new Label("Welcome to Mystic Grill");
        title.setStyle("-fx-font-size: 14px; -fx-font-weight: bold;");
        title.setPadding(new Insets(10, 0, 0, 0));
        return title;
    }

    public static Scene createScene(Stage primaryStage, Connect connection) {
        Login login = new Login(connection);
        login.start(primaryStage);
        return primaryStage.getScene();
    }

    private void loginAction(Stage primaryStage) {
        String enterUsername = username.getText();
        String enterPassword = password.getText();

        if (isValidationLogin(enterUsername, enterPassword)) {
            primaryStage.setScene(Home.createScene(primaryStage));
        } else {
            showAlert("LOGIN FAILED", "Username & Password Not Found. Please Register");
        }
    }

    private Boolean isValidationLogin(String enterUsername, String enterPassword) {
        String qry = "SELECT * FROM user WHERE userName = ? AND userPassword = ?";

        try {
            PreparedStatement preparedStatement = connection.prepareStatement(qry);
            preparedStatement.setString(1, enterUsername);
            preparedStatement.setString(2, enterPassword);

            ResultSet resultSet = preparedStatement.executeQuery();

            return resultSet.next();
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }

    private void showAlert(String title, String content) {
        Alert alert = new Alert(Alert.AlertType.ERROR);
        alert.setTitle(title);
        alert.setContentText(content);
        alert.showAndWait();
    }

    private void moveToRegisterPage(Stage primaryStage) {
        Register registerPage = new Register(connection);
        registerPage.start(primaryStage);
    }

    private static VBox createLayout(TextField username, PasswordField password, Button loginButton, Hyperlink registerLink) {
        VBox layout = new VBox(10);
        layout.setPadding(new Insets(10));
        layout.setAlignment(Pos.CENTER);
        layout.getChildren().addAll(username, password, loginButton, registerLink);
        return layout;
    }
}
