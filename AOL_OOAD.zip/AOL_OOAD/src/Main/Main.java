package Main;

import HomePage.Home;
import Regis_Login.Login;
import database.Connect;
import javafx.application.Application;
import javafx.scene.Scene;
import javafx.stage.Stage;

public class Main extends Application {

    public static void main(String[] args) {
        launch(args);
    }

    @Override
    public void start(Stage primaryStage) {
        primaryStage.setTitle("MysticGrill Apps");

        // Menampilkan halaman Home
//        Scene homeScene = Home.createScene(primaryStage);
//        primaryStage.setScene(homeScene);
//
//        primaryStage.show();
        
        //Menampilkan Login Dan Register serta Home
        Connect connection = Connect.getConnection();
        
        Login login = new Login(connection);
        login.start(primaryStage);
        
        primaryStage.show();
        
        
    }
}

