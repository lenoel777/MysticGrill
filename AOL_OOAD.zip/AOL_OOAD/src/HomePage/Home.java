package HomePage;

import View.Add_Order;
import View.Update_Order;
import javafx.scene.Scene;
import javafx.scene.control.Label;
import javafx.scene.control.Menu;
import javafx.scene.control.MenuBar;
import javafx.scene.control.MenuItem;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;

public class Home {

	public static Scene createScene(Stage primaryStage) {
        BorderPane layout = new BorderPane();

        MenuBar menuBar = createMenuBar(primaryStage);
        layout.setTop(menuBar);
        
        Add_Order initialPage = new Add_Order(primaryStage);
        layout.setCenter(initialPage);

        Scene scene = new Scene(layout, 600, 600);
        return scene;
    }

    private static MenuBar createMenuBar(Stage primaryStage) {
        // Untuk Tab Bar View
        MenuBar menuBar = new MenuBar();

        Menu menuView = new Menu("View");
        MenuItem itemViewMenu = new MenuItem("View Menu");
        // Buat masukin Methode pindah Page
        itemViewMenu.setOnAction(e -> moveToViewMenuPage(primaryStage));

        MenuItem itemViewOrder = new MenuItem("View Order");
        itemViewOrder.setOnAction(e -> moveToViewOrderPage(primaryStage));

        menuView.getItems().addAll(itemViewMenu, itemViewOrder);

        // Untuk Tab Bar Process
        Menu menuProcess = new Menu("Process");
        MenuItem itemProcess = new MenuItem("Process");
        itemProcess.setOnAction(e -> moveToProcessPage(primaryStage));

        // Untuk Tab Bar Payment
        Menu menuPayment = new Menu("Payment");
        MenuItem itemPayment = new MenuItem("Payment");
        itemPayment.setOnAction(e -> moveToPaymentPage(primaryStage));

        // Untuk Tab Bar Profile
        Menu menuProfile = new Menu("Profile");
        MenuItem itemProfile = new MenuItem("Profile");
        itemProfile.setOnAction(e -> moveToProfilePage(primaryStage));

        // Buat Munculin Menu Bar dari Home
        menuBar.getMenus().addAll(menuView, menuProcess, menuPayment, menuProfile);

        return menuBar;
    }

    private static void moveToViewMenuPage(Stage primaryStage) {
    	Add_Order viewMenuPage = new Add_Order(primaryStage);
        setPage(primaryStage, viewMenuPage, "View Menu");
    }

    private static void moveToViewOrderPage(Stage primaryStage) {
    	Update_Order viewUpdatePage = new Update_Order(primaryStage);
    	 setPage(primaryStage, viewUpdatePage, "Order List");
    }

    private static void moveToProcessPage(Stage primaryStage) {
    	setPage(primaryStage, new Label("View Process Page"), "Process");
    }

    private static void moveToPaymentPage(Stage primaryStage) {
    	setPage(primaryStage, new Label("View Payment Page"), "Payment");
    }

    private static void moveToProfilePage(Stage primaryStage) {
    	setPage(primaryStage, new Label("View Profile Page"), "Profile");
    }
    
    private static void setPage(Stage primaryStage, javafx.scene.Node content, String pageTitle) {
    	BorderPane layout = new BorderPane();
    	
    	MenuBar menuBar = createMenuBar(primaryStage);
    	layout.setTop(menuBar);
    	
    	layout.setCenter(content);
    	
    	Scene scene = new Scene(layout, 600,600);
    	primaryStage.setScene(scene);
    	primaryStage.setTitle(pageTitle);
    	primaryStage.show();
    }
}
