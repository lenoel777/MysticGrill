package model;

import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;

import database.Connect;

public class Order {
    private int orderId, orderUserId, orderTotal;
    private String orderStatus;
    private Date orderDate;

    public Order(int orderId, int orderUserId, String orderStatus, Date orderDate, int orderTotal) {
        super();
        this.orderId = orderId;
        this.orderUserId = orderUserId;
        this.orderStatus = orderStatus;
        this.orderDate = orderDate;
        this.orderTotal = orderTotal;
    }

    public static ArrayList<Order> loadOrders() {
        ArrayList<Order> orders = new ArrayList<>();
        String query = "SELECT * FROM orders";
        ResultSet rs = Connect.getConnection().executeQuery(query);
        try {
            while (rs.next()) {
                int id = rs.getInt(1);
                int userId = rs.getInt(2);
                String status = rs.getString(3);
                Date date = rs.getDate(4);
                int total = rs.getInt(5);

                orders.add(new Order(id, userId, status, date, total));
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }

        return orders;
    }

    public static int insertOrder(int orderUserId, String orderStatus, Date orderDate, int orderTotal) {
        String query = String.format(
                "INSERT INTO orders (orderUserId, orderStatus, orderDate, orderTotal) VALUES (%d, '%s', '%s', %d)",
                orderUserId, orderStatus, orderDate, orderTotal);

        // Use PreparedStatement to get generated keys
        try (PreparedStatement ps = Connect.getConnection().prepareStatement(query)) {
            ps.executeUpdate();

            // Retrieve generated keys
            ResultSet generatedKeys = ps.getGeneratedKeys();
            if (generatedKeys.next()) {
                return generatedKeys.getInt(1); // Return the generated order ID
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }

        return -1; // Return -1 if insertion fails
    }

//	public static void deleteOrder(int id) {
//		String query = "DELETE FROM order WHERE orderId = ?";
//		PreparedStatement ps = Connect.getConnection().prepareStatement(query);
//
//		try {
//			ps.setInt(1, id);
//			ps.execute();
//		} catch (SQLException e) {
//			// TODO Auto-generated catch block
//			e.printStackTrace();
//		}
//	}

//	public static void updateOrder(int id, int orderUserId, int orderItemId, String orderStatus, Date orderDate, int orderTotal) {
//		String query = "UPDATE order SET orderUserId = ?, orderItemId = ?, orderStatus = ?, orderDate = ?, orderTotal = ? WHERE orderId = ?";
//
//		PreparedStatement ps = Connect.getConnection().prepareStatement(query);
//
//		try {
//			ps.setInt(1, orderUserId);
//			ps.setInt(2, orderItemId);
//			ps.setString(3, orderStatus);
//			ps.setDate(4, orderDate);
//			ps.setInt(5, orderTotal);
//			ps.setInt(6, id);
//			ps.execute();
//		} catch (SQLException e) {
//			// TODO Auto-generated catch block
//			e.printStackTrace();
//		}
//	}

	public int getOrderId() {
        return orderId;
    }

    public void setOrderId(int orderId) {
        this.orderId = orderId;
    }

    public int getOrderUserId() {
        return orderUserId;
    }

    public void setOrderUserId(int orderUserId) {
        this.orderUserId = orderUserId;
    }

    public int getOrderTotal() {
        return orderTotal;
    }

    public void setOrderTotal(int orderTotal) {
        this.orderTotal = orderTotal;
    }

    public String getOrderStatus() {
        return orderStatus;
    }

    public void setOrderStatus(String orderStatus) {
        this.orderStatus = orderStatus;
    }

    public Date getOrderDate() {
        return orderDate;
    }

    public void setOrderDate(Date orderDate) {
        this.orderDate = orderDate;
    }
}
