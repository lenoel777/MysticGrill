package model;

import database.Connect;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

public class MenuItem {
    private int menuItemId, menuItemPrice;
    private String menuItemName, menuItemDescription;

    public MenuItem(int menuItemId, String menuItemName, String menuItemDescription, int menuItemPrice) {
        this.menuItemId = menuItemId;
        this.menuItemName = menuItemName;
        this.menuItemDescription = menuItemDescription;
        this.menuItemPrice = menuItemPrice;
    }

    // Constructor to create MenuItem from ResultSet
    public MenuItem(ResultSet rs) throws SQLException {
        this.menuItemId = rs.getInt("menuItemId");
        this.menuItemName = rs.getString("menuItemName");
        this.menuItemDescription = rs.getString("menuItemDescription");
        this.menuItemPrice = rs.getInt("menuItemPrice");
    }

    public static ArrayList<MenuItem> loadMenuItems() {
        ArrayList<MenuItem> menuItems = new ArrayList<>();
        String query = "SELECT * FROM menuitem";
        ResultSet rs = Connect.getConnection().executeQuery(query);
        try {
            while (rs.next()) {
                menuItems.add(new MenuItem(rs));
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }

        return menuItems;
    }

    public static void insertMenuItem(String menuItemName, String menuItemDescription, int menuItemPrice) {
        String query = String.format(
                "INSERT INTO menuitem (menuItemName, menuItemDescription, menuItemPrice) VALUES ('%s', '%s', %d)",
                menuItemName, menuItemDescription, menuItemPrice);
        Connect.getConnection().executeUpdate(query);
    }
    
    public int getMenuItemId() {
        return menuItemId;
    }

    public void setMenuItemId(int menuItemId) {
        this.menuItemId = menuItemId;
    }

    public int getMenuItemPrice() {
        return menuItemPrice;
    }

    public void setMenuItemPrice(int menuItemPrice) {
        this.menuItemPrice = menuItemPrice;
    }

    public String getMenuItemName() {
        return menuItemName;
    }

    public void setMenuItemName(String menuItemName) {
        this.menuItemName = menuItemName;
    }

    public String getMenuItemDescription() {
        return menuItemDescription;
    }

    public void setMenuItemDescription(String menuItemDescription) {
        this.menuItemDescription = menuItemDescription;
    }
//
//    @Override
//    public String toString() {
//        return "MenuItem{" +
//                "menuItemId=" + menuItemId +
//                ", menuItemPrice=" + menuItemPrice +
//                ", menuItemName='" + menuItemName + '\'' +
//                ", menuItemDescription='" + menuItemDescription + '\'' +
//                '}';
//    }
}
